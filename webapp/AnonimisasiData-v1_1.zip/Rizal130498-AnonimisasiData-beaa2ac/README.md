# AnonimisasiData
Data diambil dari website akademikfkip -> https://akademikfkip.files.wordpress.com/2015/03/datawisuda325-03-2015-s1-nonreguler-new.xls
